<div class="col-sm-3 hidden-xs bootnav">
<div class="list-group">
<a class="list-group-item" href="config.php?display=systemadmin&view=dns"><?php echo _("DNS");?></a>
<a class="list-group-item" href="config.php?display=systemadmin&view=timezone"><?php echo _("Timezone");?></a>
<a class="list-group-item" href="config.php?display=systemadmin&view=hostname"><?php echo _("Hostname");?></a>
<a class="list-group-item" href="config.php?display=systemadmin&view=network"><?php echo _("Network Config");?></a>
<a class="list-group-item" href="config.php?display=systemadmin&view=notifications"><?php echo _("Notifications Config");?></a>
<a class="list-group-item" href="config.php?display=systemadmin&view=email"><?php echo _("e-mail Configuration");?></a>
<a class="list-group-item" href="config.php?display=systemadmin&view=power"><?php echo _("Power management");?></a>
<a class="list-group-item" href="config.php?display=systemadmin&view=packetcapture"><?php echo _("Packet Capture");?></a>
<a class="list-group-item" href="config.php?display=systemadmin&view=storage"><?php echo _("Storage");?></a>
</div>
</div>
</div>
</div>
</div>
